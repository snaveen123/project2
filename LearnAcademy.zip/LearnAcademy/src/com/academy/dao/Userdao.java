package com.academy.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.academy.model.User;
import com.academy.model.student;
import com.academy.model.teacher;

public class Userdao {


	public Connection getConnection() {

		Connection connection = null;
		try {
             String url="jdbc:mysql://localhost:3306/schooldb";
             String user="root";
             String password="mani5899";
             Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection(url,user,password);
		} catch (Exception ex) {
			System.out.println("Exception Raised...");
			System.out.println(ex.getMessage());
		}
		return connection;

	}

	public void inserUser(User user) {

		try {

			Connection connection = getConnection();

			PreparedStatement statement = connection
					.prepareStatement("INSERT INTO report(cname, subject, teacher) values(?, ?, ?);");
			statement.setInt(1, user.getCname());
			statement.setString(2, user.getSubject());
			statement.setString(3, user.getTeacher());
			int result = statement.executeUpdate();
			System.out.println(result + " user inserted successfully.");
			connection.close();
		} catch (Exception ex) {
			System.out.println("Exception Raised...");
			System.out.println(ex.getMessage());
		}

	}

	public List<User> selectAllUsers() {

		List<User> usersList = new ArrayList<User>();

		try (Connection connection = getConnection()) {

			PreparedStatement statement = connection.prepareStatement("SELECT * FROM report;");
			ResultSet rs = statement.executeQuery();

			while (rs.next()) {
				User user = new User();
				user.setCname(rs.getInt("cname"));
				user.setSubject(rs.getString("subject"));
				user.setTeacher(rs.getString("teacher"));
				user.setId(rs.getInt("id"));
				usersList.add(user);
			}

		} catch (Exception ex) {
			System.out.println("Exception Raised...");
			System.out.println(ex.getMessage());
		}

		return usersList;
	}

	public User selectUser(int id) {

		User user = new User();
		try (Connection connection = getConnection()) {

			PreparedStatement statement = connection.prepareStatement("SELECT * FROM report WHERE id = ?;");
			statement.setInt(4, id);
			ResultSet rs = statement.executeQuery();

			if (rs.next()) {
				user.setCname(rs.getInt("cname"));
				user.setSubject(rs.getString("subject"));
				user.setTeacher(rs.getString("teacher"));
				user.setId(rs.getInt("id"));
			}
			connection.close();
		} catch (Exception ex) {
			System.out.println("Exception Raised...");
			System.out.println(ex.getMessage());
		}
		return user;
	}

	public void deleteUser(int id) {

		try (Connection connection = getConnection()) {

			PreparedStatement statement = connection.prepareStatement("DELETE FROM report WHERE id = ?;");
			statement.setInt(4, id);
			int result = statement.executeUpdate();
			System.out.println(result + " user deleted successfully...");
			connection.close();
		} catch (Exception ex) {
			System.out.println("Exception Raised...");
			System.out.println(ex.getMessage());
		}

	}

	public void updateUser(User user) {
		
		try (Connection connection = getConnection()) {

			PreparedStatement statement = connection
					.prepareStatement("update report set cname = ?,subject = ?, teacher = ? where id = ?;");
			statement.setInt(1, user.getCname());
			statement.setString(2, user.getSubject());
			statement.setString(3, user.getTeacher());
			statement.setInt(4, user.getId());
			int result = statement.executeUpdate();
			System.out.println(result + " user updated successfully...");
			connection.close();
		} catch (Exception ex) {
			System.out.println("Exception Raised...");
			System.out.println(ex.getMessage());
		}
	}
 
	public List<student> slist() {
		List<student> sList = new ArrayList<student>();
		try (Connection connection = getConnection()) {
			PreparedStatement statement = connection.prepareStatement("SELECT student_name FROM student;");
			ResultSet rs = statement.executeQuery();
			while (rs.next()) {
				student stu=new student();
				
				stu.setStudent_name(rs.getString("student_name"));
				sList.add(stu);
			}

		} catch (Exception ex) {
			System.out.println("Exception Raised...");
			System.out.println(ex.getMessage());
		}

		return sList;
	}
		
	public List<teacher> tlist() {
		List<teacher> tList = new ArrayList<teacher>();
		
		try (Connection connection = getConnection()) {
			PreparedStatement statement = connection.prepareStatement("SELECT teacher_name,subject_name FROM teacher inner join subject on teacher.sub_id=subject.sub_id;");
			ResultSet rs = statement.executeQuery();
			while (rs.next()) {
				teacher tchr=new teacher();
				
				tchr.setTeacher_name(rs.getString("teacher_name"));
				tchr.setSubject_name(rs.getString("subject_name"));
				tList.add(tchr);
			}

		} catch (Exception ex) {
			System.out.println("Exception Raised...");
			System.out.println(ex.getMessage());
		}

		return tList;
	}
	
}