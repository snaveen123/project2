package com.academy.web;
import com.academy.dao.*;
import com.academy.model.User;
import com.academy.model.student;
import com.academy.model.teacher;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/")
public class mainservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    Userdao userDAO;
   
    public mainservlet() {
        super();
        userDAO=new Userdao();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
String action = request.getServletPath();
		
		switch(action) {
		
		case "/manage_subject":
			insertUserForm(request,response);
			break;
			
		case "/insertUser":
			insertUser(request,response);
			break;
			
		case "/deleteUser":
			deleteUser(request, response);
			break;
			
		case "/updateUserForm":
			updateUserForm(request,response);
			break;
			
		case "/updateUser":
			updateUser(request,response);
			break;
		
		case "/teacher_list":
			teacherList(request,response);
			break;
			
		case "/student_list":
			studentList(request,response);
			break;
			
		case "/class_report":
			listUsers(request,response);
			break;
			
		default:
			listUsers(request,response);
			break;
			
		}	
	}

	private void studentList(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		
		List<student> students = userDAO.slist();
		System.out.println(students);
		request.setAttribute("students", students);
		RequestDispatcher dispatcher = request.getRequestDispatcher("student-list.jsp");
		dispatcher.forward(request, response);
		
	}

	private void teacherList(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
	 
		List<teacher> teachers = userDAO.tlist();
		System.out.println(teachers);
		request.setAttribute("teachers", teachers);
		RequestDispatcher dispatcher = request.getRequestDispatcher("teacher-list.jsp");
		dispatcher.forward(request, response);
	}

	private void updateUserForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		User user = userDAO.selectUser(id);
		request.setAttribute("userdetail", user);
		RequestDispatcher dispatcher = request.getRequestDispatcher("update-form.jsp");
		dispatcher.forward(request, response);
		
	}

	private void updateUser(HttpServletRequest request, HttpServletResponse response) throws IOException {
		
		User user = new User();
		user.setCname(Integer.parseInt(request.getParameter("cname")));
		user.setSubject(request.getParameter("subject"));
		user.setTeacher(request.getParameter("teacher"));
		user.setId(Integer.parseInt(request.getParameter("id")));
		userDAO.updateUser(user);
		response.sendRedirect("mainServlet");
		
	}

	private void deleteUser(HttpServletRequest request, HttpServletResponse response) throws IOException {
		int id  = Integer.parseInt(request.getParameter("id"));
		userDAO.deleteUser(id);
		response.sendRedirect("mainServlet");
		
	}

	private void insertUser(HttpServletRequest request, HttpServletResponse response) throws IOException {
		System.out.println("Inserting New User");
		User user = new User();
		user.setCname(Integer.parseInt(request.getParameter("cname")));
		user.setSubject(request.getParameter("subject"));
		user.setTeacher(request.getParameter("teacher"));
		userDAO.inserUser(user);
		response.sendRedirect("mainServlet");
		
	}

	private void insertUserForm(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("user-form.jsp");
		dispatcher.forward(request, response);
		
	}

	private void listUsers(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<User> users = userDAO.selectAllUsers();
		System.out.println(users);
		request.setAttribute("users", users);
		RequestDispatcher dispatcher = request.getRequestDispatcher("user-list.jsp");
		dispatcher.forward(request, response);
		
	}
}


