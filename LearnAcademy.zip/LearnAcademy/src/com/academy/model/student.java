package com.academy.model;

public class student {
	String student_name;

	public String getStudent_name() {
		return student_name;
	}

	public void setStudent_name(String student_name) {
		this.student_name = student_name;
	}

	public student(String student_name) {
		super();
		this.student_name = student_name;
	}

	public student() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "student [student_name=" + student_name + "]";
	}
	

}
