package com.academy.model;

public class teacher {
	
	String teacher_name;
	String subject_name;
	public teacher() {
		super();
		// TODO Auto-generated constructor stub
	}
	public teacher(String teacher_name, String subject_name) {
		super();
		this.teacher_name = teacher_name;
		this.subject_name = subject_name;
	}
	public String getTeacher_name() {
		return teacher_name;
	}
	public void setTeacher_name(String teacher_name) {
		this.teacher_name = teacher_name;
	}
	public String getSubject_name() {
		return subject_name;
	}
	public void setSubject_name(String subject_name) {
		this.subject_name = subject_name;
	}
	@Override
	public String toString() {
		return "teacher [teacher_name=" + teacher_name + ", subject_name=" + subject_name + "]";
	}
	

}
