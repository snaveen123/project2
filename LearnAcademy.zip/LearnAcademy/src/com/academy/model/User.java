package com.academy.model;

public class User {
   int cname;
   String subject;
   String teacher;
   int id;
   
   
   
public User() {
	super();
	// TODO Auto-generated constructor stub
}
public User(int cname, String subject, String teacher, int id) {
	super();
	this.cname = cname;
	this.subject = subject;
	this.teacher = teacher;
	this.id = id;
}
public int getCname() {
	return cname;
}
public void setCname(int cname) {
	this.cname = cname;
}
public String getSubject() {
	return subject;
}
public void setSubject(String subject) {
	this.subject = subject;
}
public String getTeacher() {
	return teacher;
}
public void setTeacher(String teacher) {
	this.teacher = teacher;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
@Override
public String toString() {
	return "User [cname=" + cname + ", subject=" + subject + ", teacher=" + teacher + ", id=" + id + "]";
}
   
   
   
   
   
   
   
   
   
}
